/*
 * MinIO Go Library for Amazon S3 Compatible Cloud Storage
 * Copyright 2015-2017 MinIO, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package signer

import (
	"fmt"
	"io"
	"net/http"
	"strings"
	"testing"
)

func TestRequestHost(t *testing.T) {
	req, _ := buildRequest("dynamodb", "us-east-1", "{}")
	req.URL.RawQuery = "Foo=z&Foo=o&Foo=m&Foo=a"
	req.Host = "myhost"
	canonicalHeaders := getCanonicalHeaders(*req, v4IgnoredHeaders)

	if !strings.Contains(canonicalHeaders, "host:"+req.Host) {
		t.Errorf("canonical host header invalid")
	}
}

func buildRequest(serviceName, region, body string) (*http.Request, io.ReadSeeker) {
	endpoint := "https://" + serviceName + "." + region + ".amazonaws.com"
	reader := strings.NewReader(body)
	req, _ := http.NewRequest(http.MethodPost, endpoint, reader)
	req.URL.Opaque = "//example.org/bucket/key-._~,!@#$%^&*()"
	req.Header.Add("Accept-Encoding", "identity")
	req.Header.Add("Content-Type", "application/x-amz-json-1.0")
	req.Header.Add("Content-Length", fmt.Sprint(len(body)))
	req.Header.Add("X-Amz-Meta-Other-Header", "some-value=!@#$%^&* (+)")
	req.Header.Add("X-Amz-Meta-Other-Header_With_Underscore", "some-value=!@#$%^&* (+)")
	req.Header.Add("X-amz-Meta-Other-Header_With_Underscore", "some-value=!@#$%^&* (+)")
	req.Header.Add("X-Amz-Target", "prefix.Operation")
	return req, reader
}

// TestSignV4OutpostsCredentialScope verifies that SignV4Outposts produces a credential scope containing s3-outposts.
func TestSignV4OutpostsCredentialScope(t *testing.T) {
	req, _ := http.NewRequest(http.MethodGet, "https://myap-123.op-xyz.s3-outposts.eu-central-1.amazonaws.com/bucket/key", nil)
	req.Header.Set("Host", req.URL.Host)
	signed := SignV4Outposts(*req, "AKID", "SECRET", "", "eu-central-1")
	auth := signed.Header.Get("Authorization")
	if auth == "" {
		t.Fatal("Authorization header missing")
	}
	if !strings.Contains(auth, "s3-outposts") {
		t.Errorf("Expected Authorization credential scope to contain s3-outposts, got: %s", auth)
	}
}
